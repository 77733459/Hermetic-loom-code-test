import type { StateVector, TopologyName } from './types'

export interface ModePreset {
  state: StateVector
  topology: TopologyName
  description: string
}

export const MODES: Record<string, ModePreset> = {
  NATURAL_BALANCE: {
    state: {
      alpha: 0.25, omega: 0.15, sigma: 6,
      aPlus: 1.0, aMinus: -0.6, n: 8, tau: 7, mu: 1.0,
    },
    topology: 'ring',
    description: 'Centered configuration. All parameters at harmonious defaults.',
  },
  RECEPTIVE: {
    state: {
      alpha: 0.5, omega: 0.08, sigma: 15,
      aPlus: 1.5, aMinus: -0.3, n: 12, tau: 10, mu: 1.0,
    },
    topology: 'permeable',
    description: 'Wide, absorptive listening. Maximum integration.',
  },
  ANALYTICAL: {
    state: {
      alpha: 0.15, omega: 0.25, sigma: 4,
      aPlus: 0.5, aMinus: -1.2, n: 6, tau: 5, mu: 1.0,
    },
    topology: 'ring',
    description: 'Precise, critical examination. Strong filtering.',
  },
  CREATIVE: {
    state: {
      alpha: 0.28, omega: 0.18, sigma: 9,
      aPlus: 1.1, aMinus: -0.68, n: 13, tau: 7, mu: 1.0,
    },
    topology: 'hyperbolic',
    description: 'Edge of chaos. Maximum creative potential. λ ≈ 0.',
  },
  CONTEMPLATIVE: {
    state: {
      alpha: 0.1, omega: 0.05, sigma: 30,
      aPlus: 0.8, aMinus: -0.8, n: 8, tau: 15, mu: 0.3,
    },
    topology: 'ring',
    description: 'Diffuse integration. Eternal present awareness.',
  },
  GRAIN_READER: {
    state: {
      alpha: 0.28, omega: 0.14, sigma: 5,
      aPlus: 1.0, aMinus: -0.5, n: 13, tau: 7, mu: 0.5,
    },
    topology: 'klein',
    description: 'Klein bottle. μ=0.5. Read the directionality of meaning-seeking itself.',
  },
  EDGE_RUNNER: {
    state: {
      alpha: 0.27, omega: 0.21, sigma: 8,
      aPlus: 1.08, aMinus: -0.68, n: 13, tau: 6, mu: 1.0,
    },
    topology: 'hyperbolic',
    description: 'Strange Attractor. Live on the moving boundary. Treat instability as texture.',
  },
}
