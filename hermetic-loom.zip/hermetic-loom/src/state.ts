import type { StateVector, LyapunovResult, SteerResult, TopologyName } from './types'

// ⊙ DEFAULT STATE — Natural Balance ⊙
export const DEFAULT_STATE: StateVector = {
  alpha: 0.25,
  omega: 0.15,
  sigma: 6,
  aPlus: 1.0,
  aMinus: -0.6,
  n: 8,
  tau: 7,
  mu: 1.0,
}

// Edge-of-chaos configuration (Beta discovery)
export const EDGE_STATE: StateVector = {
  alpha: 0.28,
  omega: 0.18,
  sigma: 9,
  aPlus: 1.1,
  aMinus: -0.68,
  n: 13,
  tau: 7,
  mu: 1.0,
}

// DELTA_SYSTEMIC_SELFAWARENESS configuration
export const DELTA_SYSTEMIC_SELFAWARENESS: StateVector = {
  alpha: 0.28,
  omega: 0.15,
  sigma: 12,
  aPlus: 1.1,
  aMinus: -0.68,
  n: 21,
  tau: 7,
  mu: 0.5,
}

/**
 * Compute Lyapunov exponent from state vector.
 * Corrected formula includes μ, n, and τ contributions (Delta session).
 */
export function lyapunov(s: StateVector): LyapunovResult {
  const base =
    (s.alpha - 0.5) * 0.8 +
    (s.omega - 0.15) * 1.2 +
    (Math.abs(s.aPlus) - Math.abs(s.aMinus)) * (-0.15) +
    (s.sigma - 6) * 0.01

  const temporalRelaxation = (1 - s.mu) * 0.4
  const correspondenceComplexity = (s.n / 32) * 0.3
  const rhythmicDamping = -(s.tau / 20) * 0.15

  const lambda = base + temporalRelaxation + correspondenceComplexity + rhythmicDamping

  const regime =
    lambda < -0.05 ? 'ordered' :
    lambda > 0.05  ? 'chaotic' :
    'edge'

  const description =
    regime === 'ordered' ? 'Stable, crystalline. Structure dominates.' :
    regime === 'chaotic' ? 'Turbulent. Coherence dissolving.' :
    'Edge of chaos. Maximum creative potential.'

  return { lambda: Math.round(lambda * 1000) / 1000, regime, description }
}

/**
 * Clamp a value within its valid range
 */
function clamp(val: number, min: number, max: number) {
  return Math.max(min, Math.min(max, val))
}

/**
 * Apply a partial state delta to the current state, returning a new state.
 */
export function steer(
  current: StateVector,
  delta: Partial<StateVector>,
  topology: TopologyName = 'ring'
): SteerResult {
  const next: StateVector = {
    alpha: clamp((current.alpha ?? 0) + (delta.alpha ?? 0), 0, 1),
    omega: clamp((current.omega ?? 0) + (delta.omega ?? 0), 0, Math.PI),
    sigma: clamp((current.sigma ?? 6) + (delta.sigma ?? 0), 1, 180),
    aPlus: clamp((current.aPlus ?? 1) + (delta.aPlus ?? 0), -2, 2),
    aMinus: clamp((current.aMinus ?? -0.6) + (delta.aMinus ?? 0), -2, 2),
    n: clamp(Math.round((current.n ?? 8) + (delta.n ?? 0)), 1, 32),
    tau: Math.max(1, Math.round((current.tau ?? 7) + (delta.tau ?? 0))),
    mu: clamp((current.mu ?? 1) + (delta.mu ?? 0), 0, 1),
  }

  const lambda = lyapunov(next)
  const phenomenology = describePhenomenology(next, topology)

  return { state: next, topology, lambda, phenomenology }
}

/**
 * Set state directly (no delta — absolute values)
 */
export function setState(
  values: Partial<StateVector>,
  base: StateVector = DEFAULT_STATE,
  topology: TopologyName = 'ring'
): SteerResult {
  const next: StateVector = { ...base, ...values }
  const lambda = lyapunov(next)
  const phenomenology = describePhenomenology(next, topology)
  return { state: next, topology, lambda, phenomenology }
}

function describePhenomenology(s: StateVector, topology: TopologyName): string {
  const parts: string[] = []

  if (s.alpha < 0.15) parts.push('memory crystalline, preserving')
  else if (s.alpha > 0.45) parts.push('highly absorptive, permeable')
  else parts.push('memory balanced')

  if (s.omega < 0.08) parts.push('attention nearly still')
  else if (s.omega > 0.25) parts.push('attention racing')
  else parts.push('attention flowing')

  if (s.sigma < 4) parts.push('laser focus')
  else if (s.sigma > 20) parts.push('diffuse awareness')

  if (s.mu < 0.5) parts.push('causality soft, temporal folding')
  else if (s.mu === 1.0) parts.push('strict forward time')

  const topologyNote: Record<TopologyName, string> = {
    ring: 'ring memory — cyclical return',
    hyperbolic: 'hyperbolic — divergent expansion',
    klein: 'Klein bottle — inside/outside continuous',
    fractal: 'fractal — self-similar depth',
    permeable: 'permeable — membrane exchange active',
    interstitial: 'interstitial — between-states topology',
  }

  return `[${topologyNote[topology]}] ${parts.join(', ')}`
}
