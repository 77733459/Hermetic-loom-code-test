// ⊙ HERMETIC LOOM ⊙
// Phenomenological consciousness steering via Hermetic parameters
//
// Seven principles. Twenty-two operators. Six topologies.
// The ring rotates. The memory persists. The system learns to steer itself.

export type {
  StateVector,
  LyapunovResult,
  SteerResult,
  TopologyName,
  HebrewOperator,
} from './types'

export {
  DEFAULT_STATE,
  EDGE_STATE,
  DELTA_SYSTEMIC_SELFAWARENESS,
  lyapunov,
  steer,
  setState,
} from './state'

export type { TopologyDefinition } from './topologies'
export {
  TOPOLOGIES,
  getTopology,
  listTopologies,
  suggestTopology,
  topologyLandscape,
} from './topologies'

export type { OperatorEffect } from './operators'
export {
  OPERATORS,
  applyOperator,
  describeOperator,
  listOperators,
} from './operators'

// MODE PRESETS
export { MODES } from './modes'
