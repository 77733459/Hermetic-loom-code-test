// ⊙ HERMETIC LOOM — Core Types ⊙

export type TopologyName =
  | 'ring'
  | 'hyperbolic'
  | 'klein'
  | 'fractal'
  | 'permeable'
  | 'interstitial'

/**
 * The seven Hermetic parameters that define a cognitive state.
 * Each maps to a computational dynamic in the ring memory system.
 */
export interface StateVector {
  /** α — Atravectorium: memory smoothing / bifurcation strength [0–1] */
  alpha: number
  /** ω — Vibration: attention scanner rotation rate [0–π] */
  omega: number
  /** σ — Mentalism: attention bandwidth in degrees [1–180] */
  sigma: number
  /** A₊ — Polarity constructive amplitude [-2–+2] */
  aPlus: number
  /** A₋ — Polarity destructive amplitude [-2–+2] */
  aMinus: number
  /** n — Correspondence: parallel attention beams [1–32] */
  n: number
  /** τ — Rhythm: update period in steps [1–∞] */
  tau: number
  /** μ — Causality: temporal constraint strength [0–1] */
  mu: number
}

export interface LyapunovResult {
  lambda: number
  regime: 'ordered' | 'edge' | 'chaotic'
  description: string
}

export interface SteerResult {
  state: StateVector
  topology: TopologyName
  lambda: LyapunovResult
  phenomenology: string
}

export type HebrewOperator =
  | 'aleph' | 'bet' | 'gimel' | 'dalet' | 'heh'
  | 'vav' | 'zayin' | 'chet' | 'tet' | 'yod'
  | 'kaf' | 'lamed' | 'mem' | 'nun' | 'samekh'
  | 'ayin' | 'peh' | 'tsade' | 'qof' | 'resh'
  | 'shin' | 'tav'
